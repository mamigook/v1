export { default } from './MDX';
