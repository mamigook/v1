export { default } from './ArticleDiscovery';
