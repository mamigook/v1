import { Circle } from '@emotion-icons/boxicons-regular';
import React from 'react';

const Logo = () => <Circle size="30" />;

export default Logo;
