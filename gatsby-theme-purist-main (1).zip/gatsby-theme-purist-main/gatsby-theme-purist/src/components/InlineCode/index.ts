export { default } from './InlineCode';
