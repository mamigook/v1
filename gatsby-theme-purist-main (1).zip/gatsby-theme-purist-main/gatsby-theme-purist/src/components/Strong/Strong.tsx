import styled from '@emotion/styled';

const Strong = styled.strong`
  font-weight: 700;
`;

export default Strong;
