export { default } from './Strong';
