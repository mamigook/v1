export { default } from './HorizontalRule';
