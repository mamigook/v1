import styled from '@emotion/styled';

const Emphasis = styled.em`
  font-style: italic;
`;

export default Emphasis;
