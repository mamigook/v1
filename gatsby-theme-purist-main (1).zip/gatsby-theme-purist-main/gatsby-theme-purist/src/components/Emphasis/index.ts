export { default } from './Emphasis';
